import argparse
import googlemaps
import folium
import webbrowser
from http.server import SimpleHTTPRequestHandler, HTTPServer

# Function to create and save the map
def create_map(start_coords, end_coords, waypoints=None):
    m = folium.Map(location=start_coords, zoom_start=13)
    folium.Marker(location=start_coords, popup="Warehouse (Start)", tooltip="Start Point", icon=folium.Icon(color='green')).add_to(m)
    folium.Marker(location=end_coords, popup="Customer (End)", tooltip="End Point", icon=folium.Icon(color='red')).add_to(m)

    # Add waypoints if provided
    if waypoints:
        for point in waypoints:
            folium.Marker(location=point, popup="Waypoint", tooltip="Waypoint", icon=folium.Icon(color='blue')).add_to(m)

    # Draw route
    route = [start_coords, end_coords] + (waypoints if waypoints else [])
    folium.PolyLine(route, color="blue", weight=2.5, opacity=1).add_to(m)

    return m

# Function to serve the HTML file
def serve_map(html_file):
    port = 8000
    handler = SimpleHTTPRequestHandler
    httpd = HTTPServer(('localhost', port), handler)
    
    # Open the default web browser
    webbrowser.open(f'http://localhost:{port}/{html_file}')

    print(f"Serving '{html_file}' at http://localhost:{port}")
    httpd.serve_forever()

# Main function
def main():
    parser = argparse.ArgumentParser(description="Simulate a delivery vehicle GPS tracker")
    parser.add_argument("--start", default="12.9715987,77.594566", help="Start location (Warehouse)")
    parser.add_argument("--end", default="12.935242,77.624485", help="End location (Customer)")
    args = parser.parse_args()

    # Convert start and end locations from strings to tuples
    start_coords = tuple(map(float, args.start.split(',')))
    end_coords = tuple(map(float, args.end.split(',')))

    # Initialize Google Maps client with your API key
    api_key = 'YOUR_GOOGLE_MAPS_API_KEY'
    gmaps = googlemaps.Client(key=api_key)

    # Request directions from Google Maps API
    directions_result = gmaps.directions(args.start, args.end, mode="driving")

    # Extract route coordinates from the directions response
    route_coords = []
    for leg in directions_result[0]['legs']:
        for step in leg['steps']:
            start_point = step['start_location']
            end_point = step['end_location']
            route_coords.append((start_point['lat'], start_point['lng']))
            route_coords.append((end_point['lat'], end_point['lng']))

    # Create and save the map
    m = create_map(start_coords, end_coords, waypoints=route_coords[1:-1])  # Exclude start and end points
    html_file = 'delivery_simulation_map.html'
    m.save(html_file)
    print(f"Map saved as '{html_file}'")

    # Serve the HTML file on a local server
    serve_map(html_file)

if __name__ == "__main__":
    main()
