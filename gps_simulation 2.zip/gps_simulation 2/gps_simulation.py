import argparse
import time
import folium
from tqdm import tqdm  # Progress bar
import paho.mqtt.client as mqtt  # MQTT client

# Example logging function
def log(data):
    print(f"Logging data: {data}")

# MQTT callback function
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT broker")
    else:
        print(f"Failed to connect to MQTT broker with code {rc}")

def main():
    parser = argparse.ArgumentParser(description="Simulate a GPS tracker")
    parser.add_argument("--start", default="Start Location", help="Start location")
    parser.add_argument("--end", default="End Location", help="End location")
    parser.add_argument("--interval", type=int, default=10, help="Interval in seconds")
    parser.add_argument("--duration", type=int, default=3600, help="Duration in seconds")
    args = parser.parse_args()

    # Generate mock coordinates (replace with your actual data or simulation logic)
    coordinates = [
        (40.7128, -74.006),    # Example coordinate 1 (New York)
        (34.0522, -118.2437),  # Example coordinate 2 (Los Angeles)
        (51.5074, -0.1278),    # Example coordinate 3 (London)
    ]

    # Initialize map centered on the first coordinate
    map_center = coordinates[0]
    m = folium.Map(location=map_center, zoom_start=5)

    # Add markers for start and end locations with tooltips
    folium.Marker(location=coordinates[0], popup=f"Start Location: {args.start}", tooltip="Start Point", icon=folium.Icon(color='green')).add_to(m)
    folium.Marker(location=coordinates[-1], popup=f"End Location: {args.end}", tooltip="End Point", icon=folium.Icon(color='red')).add_to(m)

    print(f"Simulating from {args.start} to {args.end}")
    print(f"Total route distance: {len(coordinates)} points")
    print(f"Total route duration: {args.duration} seconds")

    # Set up MQTT client (optional, for demonstration)
    client = mqtt.Client()
    client.on_connect = on_connect
    client.connect("test.mosquitto.org", 1883, 60)
    client.loop_start()

    # Batch processing of coordinates
    batch_size = 1  # Adjust batch size based on your data or simulation logic
    total_points = len(coordinates)
    num_batches = total_points // batch_size

    for batch_idx in tqdm(range(num_batches)):
        start_idx = batch_idx * batch_size
        end_idx = min(start_idx + batch_size, total_points)
        batch_coords = coordinates[start_idx:end_idx]

        for coord in batch_coords:
            log_data = {"coordinates": {"lat": coord[0], "lng": coord[1]}}
            log(log_data)  # Logging function call

            # Publish coordinates to MQTT topic (optional, for demonstration)
            client.publish("gps_simulation/coordinates", str(log_data))

            # Add marker to map with tooltip showing the coordinate
            folium.Marker(location=coord, popup=f"Coordinates: {coord}", tooltip=f"Coordinates: {coord}").add_to(m)

        time.sleep(args.interval)

    client.loop_stop()

    # Save the final map as an HTML file
    m.save('gps_simulation_map.html')
    print("Map saved as 'gps_simulation_map.html'")

if __name__ == "__main__":
    main()
