## GPS Simulation Project

### Overview

This project simulates a GPS tracker moving from a start location to an end location, displaying coordinates on an interactive map using Folium.

### Usage

#### Running the Simulation

1. Ensure Python 3.6+ and required packages are installed (`pip install -r requirements.txt`).
2. Navigate to the project directory and run `python simulate.py --start "Start Location" --end "End Location" --interval 10 --duration 3600`.

#### Interacting with the Map

- **Zoom**: Use the mouse scroll wheel or map zoom controls.
- **Pan**: Click and drag the map to move around.
- **Markers**: Click on markers to view details (time, coordinates).

#### Saving the Map

After running the simulation, the map with simulated coordinates can be saved as an HTML file:

```bash
m.save('gps_simulation_map.html')
