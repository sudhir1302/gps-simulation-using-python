# utils/tracker_sim.py

import numpy as np

class TrackerSim:
    def __init__(self, coordinates):
        self.coordinates = coordinates
        self.current_index = 0

    def get_coords(self, elapsed_time):
        index = min(len(self.coordinates) - 1, int(elapsed_time / 10))
        return self.coordinates[index]

def generate_mock_coordinates(start, end, num_points=100):
    lat_start, lon_start = start
    lat_end, lon_end = end

    latitudes = np.linspace(lat_start, lat_end, num_points)
    longitudes = np.linspace(lon_start, lon_end, num_points)

    return list(zip(latitudes, longitudes))
