# utils/utils.py

def log(data):
    print(f"Logging data: {data}")
