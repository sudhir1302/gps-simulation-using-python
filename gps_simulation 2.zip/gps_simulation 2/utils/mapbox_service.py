# utils/mapbox_service.py

import requests

class MapboxService:
    def __init__(self, api_key):
        self.api_key = api_key

    def get_coordinates(self, location):
        url = f"https://api.mapbox.com/geocoding/v5/mapbox.places/{location}.json?access_token={self.api_key}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        return data['features'][0]['geometry']['coordinates']

    def get_directions(self, start_coords, end_coords):
        url = (
            f"https://api.mapbox.com/directions/v5/mapbox/driving/"
            f"{start_coords[0]},{start_coords[1]};{end_coords[0]},{end_coords[1]}"
            f"?geometries=geojson&access_token={self.api_key}"
        )
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        route = data['routes'][0]
        return route['geometry']['coordinates'], route['duration'], route['distance']
