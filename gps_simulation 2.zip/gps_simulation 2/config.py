# config.py

mqtt_server_ip = "test.mosquitto.org"
mqtt_server_port = 1883  # default MQTT port
mqtt_server_keepalive = 60  # or the appropriate keepalive interval
start_location = "Start Location"  # Placeholder
end_location = "End Location"  # Placeholder
interval = 10  # seconds
duration = 3600  # seconds
